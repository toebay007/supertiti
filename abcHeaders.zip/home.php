<?php include "start.php";  ?>
<div class="row">
    <div class="col-md-2 adDivs advivs text-center">
        <?php include "sidebar.php"; ?>
    </div>
    <div class="col-md-10 adDivs">
       <!-- div for dashboard -->
       <div class="row mt-2">
            <h4 class="text-center">Dashboard</h4>
            <div class="col-md-1 admdivs"></div>
            <div class="col-md-4 admDivs">
                <h3 class="text-center" style="color: black;">Welcome Back!</h3>
            </div>
            <div class="col-md-2 admdivs"></div>
            <div class="col-md-4 admDivs">
                <h3 class="text-center" style="color: black;">Total Products <span>4</span></h3>
            </div>
            <div class="col-md-1 admdivs"></div>
        </div>
        <div class="row" style="margin-top: 40px;">
            <div class="col-md-1 admdivs"></div>
            <div class="col-md-4 admDivs">
                
            </div>
            <div class="col-md-2 admdivs"></div>
            <div class="col-md-4 admDivs">
                
            </div>
            <div class="col-md-1 admdivs"></div>
        </div>
       <!-- end of divs for dashboard -->
    </div>
</div>


<?php include "xyzFooters.php";  ?>