<?php include "abcHeaders.php"; ?>

<div class="col-md-12"> 
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end">
                <li class="breadcrumb-item"><a href="index.php" class="breadcrumbs">Home</a></li>
                <li class="breadcrumb-item active">Member</li> 
            </ol>
        </nav>
    </div>


<!-- memership -->
<!-- heading -->
<div class="row">
        <div class="col-md-10 offset-md-1 abtH text-center">
            <h4 class="abtHe">Join my Team</h4>
        </div>
    </div>
    <!-- end of header -->
<div class="row">
    <div class="col-md-1 memb"></div>
    <div class="col-md-5 memb">
        <p style="font-size: 1.2rem;">
        Join Superlife 30’s distributor community and start earning a residual income, bonuses and health products both in Dollar and Naira.
Market Potential of Stem cell Business.
Former US president Obama pumped in large Amount of Federal Taxpayer Money to research in Live cell Therapy. He Estimated that within the next 10 years, 80% of the population from developed countries will be tied to STEM CELL.
– Meaning that market potential of this product (STC) are estimated to reach US$50 billions in the next 10 years.
– Many will become millionaires from marketing products and services related to STC.
        </p>
    </div>
    <div class="col-md-5 memb">
        <img src="img/tFruit.jpeg" alt="about" width="100%" height="300px">
    </div>
    <div class="col-md-1 memb"></div>
</div>
<!-- first member slide -->
<div class="row">
    <div class="col-md-1 memb"></div>
    <div class="col-md-5 memb">
        <img src="img/5fruit.jpeg" alt="contact" width="100%" height="300px">
    </div>
    <div class="col-md-5 memb">
        <p style="font-size: 1.2rem;">
        Experience financial freedom with Super Life, sell and earn over N500k monthly without stress. Contact us now via the form below; membership and registration is FREE!
REQUIREMENTS
        </p>
        <p><i class="bi bi-envelope" style="font-size: 1.5rem;"></i> <span>Email</span></p>
        <p><i class="bi bi-person-lines-fill" style="font-size: 1.5rem;"></i> <span>Phonebook</span></p>
        <p><i class="bi bi-person-circle" style="font-size: 1.5rem;"></i> <span>Fullname and Details</span></p>
        <p><i class="bi bi-camera" style="font-size: 1.5rem;"></i> <span>Profile picture</span></p>
        <p style="font-size: 1.5rem;">Follow this link to join my WhatsApp group:</p>
        <div class="d-grid gap-2">
            <a href="https://wa.me/+353862521470/?text=Good day, i got your number from your website, i would love to join the Network. My name is ______"><button class="button">Contact me on Whatsapp for more details</button></a>
        </div>
    </div>
    <div class="col-md-1 memb"></div>
</div>
<!-- end of First -->


<?php  include "xyzFooters.php";  ?>